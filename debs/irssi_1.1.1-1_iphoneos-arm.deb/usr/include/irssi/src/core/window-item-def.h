#ifndef __WINDOW_ITEM_DEF_H
#define __WINDOW_ITEM_DEF_H

#define STRUCT_SERVER_REC SERVER_REC
struct _WI_ITEM_REC {
#include "window-item-rec.h"
};

#endif
